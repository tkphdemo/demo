// tests go here; this will not be compiled when this package is used as an extension.
basic.forever(function () {
    basic.showString("" + (IR.IR_read()))
})
